@extends('layouts.app')
@section('content')
    <h1 class="text-success">Utilisateur supprimé !</h1>
@endsection