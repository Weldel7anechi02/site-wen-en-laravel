<?php
//$myTest = 'aâéèàçêôîëÄÂäËöÖ';
//$leurTest = "ʿABBĀSĀBĀD";
//$new = iconv('UTF-8', 'us-ascii//TRANSLIT//IGNORE', $myTest);
//var_dump(preg_replace('/[\"\\\'\`\^]/', '', $new));
//var_dump(bcrypt('antoine'));