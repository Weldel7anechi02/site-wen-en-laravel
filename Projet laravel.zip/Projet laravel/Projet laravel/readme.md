**** 

**FreeAds — Plateforme de petites annonces**

**Description:**
- **Objectif :** FreeAds est une petite plateforme de petites annonces qui permet aux utilisateurs de publier des annonces (posts), d'envoyer et recevoir des messages liés aux annonces, et de gérer un profil utilisateur.

**Fonctionnement général :**
- L'application est construite avec Laravel (MVC). Les visiteurs peuvent parcourir les annonces (`/`, `/home`, `/posts`).
- Les utilisateurs s'enregistrent et confirment leur email (route de vérification). Une fois connectés, ils peuvent créer, modifier et supprimer leurs annonces, et envoyer des messages à d'autres utilisateurs concernant une annonce.

**Installation (local, Windows) :**
1. Cloner le dépôt et se placer dans le dossier du projet :

```bash
git clone <repo-url>
cd freeads-master/freeads-master
```

2. Installer les dépendances PHP (Composer) :

```bash
composer install
```

3. Copier le fichier d'environnement et générer la clé d'application :

```bash
copy .env.example .env
php artisan key:generate
```

4. Configurer `.env` (base de données, mail, etc.) puis exécuter les migrations :

```bash
php artisan migrate
```

5. (Optionnel) Installer les dépendances JS et compiler les assets :

```bash
npm install
npm run dev
```

6. Démarrer le serveur local Laravel :

```bash
php artisan serve
```

Le site sera accessible par défaut sur http://127.0.0.1:8000

**Commandes utiles :**
- `composer install` : installe les dépendances PHP
- `php artisan migrate` : exécute les migrations
- `php artisan serve` : lance le serveur local
- `npm install` / `npm run dev` : gestion des assets front

**Routes principales & API (documentation)**

Remarque : l'application utilise les routes web définies dans `routes/web.php` et une route API minimale dans `routes/api.php`.

**Authentification (généré par `Auth::routes()`) :**
- POST `/login` (connexion)
- POST `/logout` (déconnexion)
- GET|POST `/register` (inscription)
- Password reset routes : `/password/reset`, etc.

**Pages générales :**
- GET `/` : page d'accueil (vue `welcome`)
- GET `/home` : page principale listant les annonces (`PostsController@index`). Paramètres GET optionnels :
    - `search` (string) — mot-clé de recherche
    - `category` (string)
    - `user` (int) — id utilisateur
    - `priceMin` / `priceMax` (num)
    - `picture` (bool) — présence d'image

**Ressource `posts` (controller : `PostsController`) :**
- GET `/posts` — lister les annonces (mêmes filtres que `/home`).
- GET `/posts/create` — formulaire de création (auth requis).
- POST `/posts` — créer une annonce (auth requis).
    - Paramètres requis (form-data / application/x-www-form-urlencoded): `title`, `content`, `price`.
    - Fichiers optionnels : `picture1`, ..., `picture5` (multipart file).
- GET `/posts/{id}` — afficher une annonce.
- GET `/posts/{id}/edit` — formulaire d'édition (propriétaire requis).
- PUT/PATCH `/posts/{id}` — mettre à jour (propriétaire requis). mêmes champs que `POST /posts`.
- DELETE `/posts/{id}` — supprimer (propriétaire requis).

Exemple curl (création d'une annonce) :

```bash
curl -X POST http://127.0.0.1:8000/posts \
    -F "title=Mon annonce" \
    -F "content=Description de l'annonce" \
    -F "price=100" \
    -F "picture1=@/chemin/vers/photo.jpg" \
    -b "laravel_session=<session_cookie>"
```

Réponse attendue : redirection vers `/posts` avec message flash (HTML).

**Ressource `messages` (controller : `MessagesController`) :**
- GET `/messages/create/{post}/{receiver}/{sender}` — formulaire de message pré-rempli (post id, receiver id, sender id).
- POST `/messages` — envoyer un message.
    - Paramètres requis: `title`, `content`, `sender_id`, `receiver_id`, `post_id`.
- GET `/messages/{id}` — afficher un message (expéditeur/récepteur autorisés).
- GET `/messages/{id}/edit` — formulaire d'édition.
- PUT/PATCH `/messages/{id}` — mettre à jour un message.
- DELETE `/messages/{id}` — supprimer un message.

Exemple curl (envoyer un message) :

```bash
curl -X POST http://127.0.0.1:8000/messages \
    -d "title=Question&content=Bonjour, est-ce disponible?&sender_id=1&receiver_id=2&post_id=10" \
    -b "laravel_session=<session_cookie>"
```

Réponse attendue : redirection HTML vers la liste de messages de l'utilisateur.

**Ressource `users` (controller : `UserController`) :**
- Resource CRUD standard :
    - GET `/users` — lister (dev/debug affiche les noms)
    - GET `/users/create` — formulaire inscription
    - POST `/users` — créer utilisateur
    - GET `/users/{user}` — afficher profil
    - GET `/users/{user}/edit` — éditer
    - PUT/PATCH `/users/{user}` — mettre à jour
    - DELETE `/users/{user}` — supprimer
- GET `/users/{user}/messages` — lister les messages reçus/envoyés (paramètre GET `search` optionnel).
- GET `/users/{user}/delete` — formulaire de confirmation de suppression.

Exemple curl (requête JSON utilisateur authentifié via API) :

```bash
curl -H "Authorization: Bearer <token>" http://127.0.0.1:8000/api/user
```

Réponse (exemple JSON) :

```json
{
    "id": 1,
    "name": "Alice",
    "email": "alice@example.com",
    "verified": 1,
    "created_at": "2020-01-01T00:00:00.000000Z"
}
```

**Vérification d'email :**
- GET `/user/verify/{token}` — vérifie et active l'utilisateur (contrôleur : `Auth\RegisterController@verifyUser`).

**API `routes/api.php` :**
- GET `/api/user` — retourne l'utilisateur authentifié (middleware `auth:api`).

**Paramètres d'authentification :**
- Les opérations de création/modification/suppression requièrent que l'utilisateur soit connecté et, pour certaines actions (édition/suppression), que l'utilisateur possède l'élément (ownership) ou soit administrateur selon la logique interne.

**Notes & annexes :**
- Les réponses sont majoritairement des vues HTML et redirections (application web classique). L'API JSON est limitée (`/api/user`).
- Pour le développement, configurez les paramètres mail dans `.env` afin que l'envoi d'email de vérification fonctionne.

Si vous voulez, je peux :
- Ajouter des exemples de réponses JSON pour chaque endpoint.
- Générer un fichier `README.md` plus détaillé avec captures d'écran et diagramme des routes.

---


## Description Sujet 

* Créer un site vente en ligne avec systeme d'authentification Admin/user
    * Confirmation de compte avec Mail
    * Reinitialiser Mot de Passe Avec Mail
* Possibilité Créer et consulter annonces
    ** Systeme de CRUD en SQL
* Possibilité Filtrer annonce avec recherche par :
    * correspondance de mots avec priorité _pour les titres_
    * critères :
        * categories
        * utilisateur
        * avec images Uniquement
        * Fourchette de prix
* Temps du Projet 5 Jours 
## Première étape

* lancer un terminal à la racine du dossier du projet 
    * Laravel development server started on http://127.0.0.1:8000/
### Prérequis

* Lancez Sur le **serveur** en **local**
    
  * Pour MacOS installez [MAMP](https://documentation.mamp.info/en/MAMP-Mac/Installation/)
  * Lancez Ces commandes dans un terminal quand vous etes dans le parent du dossier Puissance 4 
  *  
  * Pour Ubuntu installez Apache2
  * 

### Installing

Disponible sous le serveur artisan de laravel

lancez un navigateur sous :

    http://127.0.0.1:8000/

## Authors

* **Antoine Guerra** - *Projet Pour EPITECH* - [EPITECH](http://www.epitech.eu/)

## Built With

* Laravel

<p align=center><img src=https://laravel.com/assets/img/components/logo-laravel.svg></p>

<p align=center>
<a href=https://travis-ci.org/laravel/framework><img src=https://travis-ci.org/laravel/framework.svg alt=Build Status></a>
<a href=https://packagist.org/packages/laravel/framework><img src=https://poser.pugx.org/laravel/framework/d/total.svg alt=Total Downloads></a>
<a href=https://packagist.org/packages/laravel/framework><img src=https://poser.pugx.org/laravel/framework/v/stable.svg alt=Latest Stable Version></a>
<a href=https://packagist.org/packages/laravel/framework><img src=https://poser.pugx.org/laravel/framework/license.svg alt=License></a>
</p>

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable, creative experience to be truly fulfilling. Laravel attempts to take the pain out of development by easing common tasks used in the majority of web projects, such as:

- [Simple, fast routing engine](https://laravel.com/docs/routing).
- [Powerful dependency injection container](https://laravel.com/docs/container).
- Multiple back-ends for [session](https://laravel.com/docs/session) and [cache](https://laravel.com/docs/cache) storage.
- Expressive, intuitive [database ORM](https://laravel.com/docs/eloquent).
- Database agnostic [schema migrations](https://laravel.com/docs/migrations).
- [Robust background job processing](https://laravel.com/docs/queues).
- [Real-time event broadcasting](https://laravel.com/docs/broadcasting).

Laravel is accessible, yet powerful, providing tools needed for large, robust applications. A superb combination of simplicity, elegance, and innovation give you tools you need to build any application with which you are tasked.

## Learning Laravel

Laravel has the most extensive and thorough documentation and video tutorial library of any modern web application framework. The [Laravel documentation](https://laravel.com/docs) is thorough, complete, and makes it a breeze to get started learning the framework.

If you're not in the mood to read, [Laracasts](https://laracasts.com) contains over 900 video tutorials on a range of topics including Laravel, modern PHP, unit testing, JavaScript, and more. Boost the skill level of yourself and your entire team by digging into our comprehensive video library.

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](http://laravel.com/docs/contributions).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell at taylor@laravel.com. All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).




**Exemples de requêtes et réponses (JSON) — Représentations modèles**

Les contrôleurs renvoient principalement des vues HTML mais voici des exemples JSON utiles pour des appels API ou pour documenter les modèles.

- Exemple d'une ressource `Post` (GET `/posts/{id}`) :

```json
{
    "id": 10,
    "title": "Vélo tout-terrain",
    "content": "Vélo en bon état, 21 vitesses, pneus récents.",
    "picture1": "storage/uploads/velo1.jpg",
    "picture2": null,
    "picture3": null,
    "picture4": null,
    "picture5": null,
    "price": 120,
    "category": "Sports",
    "user_id": 3,
    "created_at": "2020-01-10T12:34:56.000000Z",
    "updated_at": "2020-01-12T09:00:00.000000Z"
}
```

- Exemple de liste paginée `GET /posts` :

```json
{
    "current_page": 1,
    "data": [ { /* Post objets comme ci-dessus */ } ],
    "first_page_url": "http://127.0.0.1:8000/posts?page=1",
    "from": 1,
    "last_page": 5,
    "per_page": 50,
    "to": 50,
    "total": 240
}
```

- Exemple d'une ressource `Message` (GET `/messages/{id}`) :

```json
{
    "id": 42,
    "title": "Question au sujet de l'annonce",
    "content": "Bonjour, est-ce toujours disponible ?",
    "post_id": 10,
    "sender_id": 1,
    "receiver_id": 3,
    "viewed": true,
    "created_at": "2020-01-11T08:30:00.000000Z"
}
```

- Exemple d'utilisateur (GET `/api/user` ou représentation JSON) :

```json
{
    "id": 3,
    "name": "Alice",
    "email": "alice@example.com",
    "role": "user",
    "verified": 1,
    "created_at": "2019-12-01T10:00:00.000000Z"
}
```

**Exemples curl (auth via cookie session ou token)**

- Récupérer la page d'accueil (HTML) :

```bash
curl http://127.0.0.1:8000/
```

- Récupérer la liste des posts (JSON si API adaptée) :

```bash
curl -H "Accept: application/json" "http://127.0.0.1:8000/posts?search=velo&category=Sports"
```

- Créer une annonce (avec cookie de session Laravel) :

```bash
curl -X POST http://127.0.0.1:8000/posts \
    -F "title=Mon annonce" \
    -F "content=Description" \
    -F "price=100" \
    -F "picture1=@/chemin/photo.jpg" \
    -b "laravel_session=<session_cookie>"
```

- Envoyer un message (form-data / x-www-form-urlencoded) :

```bash
curl -X POST http://127.0.0.1:8000/messages \
    -d "title=Question&content=Bonjour&sender_id=1&receiver_id=3&post_id=10" \
    -b "laravel_session=<session_cookie>"
```

- Appel API protégé par token (ex: `/api/user`) :

```bash
curl -H "Authorization: Bearer <token>" -H "Accept: application/json" http://127.0.0.1:8000/api/user
```

Notes finales :
- Les endpoints renvoient majoritairement des vues et effectuent des redirections. Si vous souhaitez une API REST JSON complète, je peux :
    - Ajouter des routes API et transformer les contrôleurs pour renvoyer JSON
    - Générer une documentation OpenAPI/Swagger

---


