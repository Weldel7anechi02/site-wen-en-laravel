// 404 Error page
//Responsive: Large desktop (1800px), Standard, Mobile (568px)


// iPhone pull addressbar (Optional)
/mobile/i.test(navigator.userAgent) && !window.location.hash && setTimeout(function () {
    window.scrollTo(0, 1);
}, 1000);

